<?php declare(strict_types=1);

class Image
{

    public $id;

    function upload(){

    }

}