<?php
    require_once "../layout/header.php";

    /*
     * PHP CODE
     */
?>


    <!-- ======= ROW 1 ======= -->
    <section id="about-us" class="about-us">
        <div class="container" data-aos="fade-up">
            <div class="row content">


                  ANY FORM DATA HERE


                </form>
            </div>
        </div>
    </section>
    <!-- End ROW 1 -->


    <!-- ======= ROW 2 ======= -->
    <section id="team" class="team section-bg">
        <div class="container" data-aos="fade-up">


            ANY FORM DATA HERE


        </div>
    </section>
    <!-- End ROW 2 -->


    <!-- ======= ROW 3 ======= -->
    <section id="skills" class="skills">
        <div class="container" data-aos="fade-up" >
            <div class="row skills-content" >

                ANY FORM DATA HERE

            </div>
        </div>
    </section>
    <!-- End ROW 3 -->


<?php include "../layout/footer.php"; ?>